% Computer Vision - MAI
% Pablo Mart�nez and Aleix Solanes
% 1.6 Treating color images
% Given the images hand.jpg and mapfre.jpg, create the function fuseImg(),
% which represents the following points:
% a) Open hand.jpg and convert it to gray scale image
% b) Perform a binarization to obtain a binary image of 2 regions: the hand
% (called foreground) and the rest(called background). Create the inverse
% binary image changing the areas of foreground and background.
% c) use the binary matrices created in b) to merge the images hand and
% mapfre.
%d) save the image as hand_mapfre_3C.jpg

% As it was asked, all the steps are reproduced inside the code of the
% function fuseImg(); In this file, there is only its call.
fuseImg();